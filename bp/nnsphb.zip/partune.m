% partune.m
% partition the training data samples into a training 
% set and a tuning set according to a user specified percentage ratio
% then save them back in ASCII format into two files.
% (C) copyright 2001 by Yu Hen Hu
% created: 3/19/2001
clear all
dir
file_name=input(' Enter training filename in single quote, no file extension: ');
eval(['load ' file_name]);   % load training file
train0=eval(file_name); [Kr,MN]=size(train0);
disp(['Input dimension + Output dimension = ' num2str(MN)]);
M=input(' # of MLP inputs (feature space dimension) M = ');
N=MN-M; disp([' so output dimension (# of classes) = ' num2str(N)]);

% ==============================================================
% data analysis of training set data
% ==============================================================

% A. find prior distribution assuming each output is a separate class
%    and output encoding is 1 of N method
disp(['Total number of training samples = ' int2str(Kr)]);
if N==1, % 1 output, two classes case
   nc1=sum(train0(:,MN)); 
   disp(['no. of class 0 training samples = ' int2str(Kr-nc1) ' (' num2str(100*(1-nc1/Kr)) '%)']);
   disp(['no. of class 1 training samples = ' int2str(nc1) ' (' num2str(100*nc1/Kr) '%)']);
elseif N>1,
   nc=sum(train0(:,M+1:MN));
   for n=1:N,
      disp(['no. of class ' int2str(nc(n)) ' training samples = ' ...
            int2str(nc(n)) ' (' num2str(100*nc(n)/Kr) '%)']);
   end
end

% B. Determine percentage of training samples should be reserved for cross validation.
disp('Enter the percentage of training samples (0 to 100)');
prc=input('for cross validation: ');
train1=[]; tune=[];
for i=M+1:MN,
   idx=find(train0(:,i)==1);
   [ridx,tidx]=fsplit(idx,prc,2);
   train1=[train1;train0(ridx,:)]; 
   tune=[tune;train0(tidx,:)];
end

save bptrain train1 -ascii
save bptune tune -ascii
