% MOEdemo.m -Mixture of Expert network demonsration program 
% copyright (C) 2001 by Yu Hen Hu
% created: Feb. 23, 2001
% call fungenf.m, cinit.m, rbn.m, gauss.m

clear all, figure(1),clf
% generate 1D data trainf, testf
Nr=input('# of training samples = '); 
Nt=input('# of testing samples = '); 

% generate the training and testing data samples
funtype=input('1. Sinusoids, 2. piecewise linear, or 3. polynomial. Enter choice: ');
switch funtype
   case 1  % a sinusoidal signal is to be generated
      tp=[.7 -.2]; % y = cos(4*pi*0.7*x + (-.2))
   case 2  % piecewise linear function
      tp=[-.5 0 -.1 .2 .1 .2 .3 1 .5 0];
   case 3 % polynomial specified by roots
      tp=[2 -.3 0 0.2];
end
xgen=0;    % only regularly spaced data samples are generated
xorder=2; % training and testing data are evenly interlaced
[trainf,testf]=fungenf(Nr,Nt,xgen,funtype,tp,xorder);
x=trainf(:,1); d=trainf(:,2); 
y=testf(:,1); yd=testf(:,2);

% generate fixed gating network output using clustering 
[k,n]=size(x); % m # of samples, n: dim of feature space

% gating network
figure(1),subplot(121),plot(x,d,'.'),drawnow
c=input('number of experts used = '); 
% member is the hard membership k x 1 vector
% g is soft membership c x k
% xi: clustering (expert) centers, c by n
[g,member,xi]=moegate(x,c); 

% training individual experts with the partitioned sets of data
% using a linear model
x1=[ones(k,1) x]; % first input is the bias term
for i=1:c, % for each of the c experts
   xe=x1(find(member==i),:); de=d(find(member==i),:);
   w(:,i)=pinv(xe)*de; % weights of i-th experts, (n+1) x 1 vector
end

% moe training output
rout=x1*w; % (k by n+1) x (n+1 by c) = k by c;
if c>1,
   r=(sum(rout'.*g))'; % r is k by 1
elseif c==1,
   r=rout;
end

figure(1),subplot(121),plot(x,d,'.g',xi,zeros(size(xi)),'o',x,r,'-r')
title('training data results'), vx=axis;

% moe testing output
gt=moegate(y,c,xi);  % gt is c by Nt
tout=[ones(Nt,1) y]*w; % (Nt by n+1) x (n+1 by c) = Nt by c;
if c>1,
   tt=(sum(tout'.*gt))'; % y is k by 1
elseif c==1,
   tt=tout;
end

figure(1),subplot(122),plot(y,yd,'.g',xi,zeros(size(xi)),'o',y,tt,'-r')
title('testing data results'),
%axis([-.5 .5 min(min(tt),min(yd))-.2 max(max(tt),max(yd))+.2])
axis(vx)

