function [Cmat,crate]=bptest(w,test,atype)
% Usage: [Cmat,crate]=bptest(w,test,atype)
% This routine is used for pattern classification problems only.
% testing MLP network for classification rate and confusion matrix
% test (K by M+N) the feature vectors (K by M) and target vectors (K by N)
% w{l}, 1<= l <= L consists of the L-1 weight matrices, w{1}=[].
%       each w{l} is n(l) x (n(l-1)+1)
% assume the output uses 1 of N encoding. Thus, class #1 is [1 0 ... 0]
%       class #2 is [0 1 0 .. 0], etc.
% type(1:L): specify activation function types for each layer
%       if ignored, type(l) = 1
% Cmat: N by N the confusion matrix
% crate = sum(diag(Cmat))/K: classification rate
%
% used by cvgtest.m
%
% copyright (c) 1996-2001 by Yu Hen Hu
% Last modified: 3/20/2001

if nargin<3, atype=ones(length(w),1); end

[K,MN]=size(test); % find # of samples and input+output dimension
[m1,M1]=size(w{2});  % find input dimension
M=M1-1; 
N=MN-M;
L=length(w);

z{1}=(test(:,1:M))'; % input sample matrix  M by K
target=test(:,M+1:MN)';   % corresponding target value  N by K
   
% Feed-forward phase,  
for l=2:L,               % the l-th layer
  z{l}=actfun(w{l}*[ones(1,K);z{l-1}],atype(l)); % z{l} is n(l) by K
end

% To compute confusion matrix, we need at least two outputs. If the MLP has
% only one output to encode two classes, we change it to a 1 out of 2 encoding
if N==1,
   z{L}=[[z{L}>0.5];[z{L}<0.5]];
   target=[target;ones(1,K)-target]; 
   N=2;  % change size of confusion matrix to 2 by 2
end

% Then we calculate the NxN confusion matrix.
Cmat=[(target-ones(N,1)*max(target))==0]*[(z{L} - ones(N,1)*max(z{L})) == 0]'; 
crate=sum(diag(Cmat))*100/K;
