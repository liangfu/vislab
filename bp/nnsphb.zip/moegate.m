function [g,member,xi]=moegate(x,c,xi)
% Usage: [g,member,xi]=moegate(x,c,xi)
% Implement gating network for Mixture of expert
% Input: x - K by N
%        c - # of experts
%        xi - clustering centers if provided, then no need to use kmeans training
% Output: g - gating network output
%        member - hard membership of each sample to xi   K by 1 vector
%        xi - if input is provided, xi will not change, otherwise, it will be 
%             computed using kmeans algorithm
% Mfiles called: cinit.m, kmeansf.m, kmeantest.m
%
% (C) 2001 By Yu Hen Hu
% created: 4/2/2001

if c>1,
   if nargin==2, % if xi is NOT provided, then find it (training phase)
      xi=cinit(x,2,c); % spread initial cluster center over entire range
      xi=kmeansf(x,xi,.0001,50);  % updated cluster centers
   end
   [err,member,dist]=kmeantest(x,xi); % dist is distance square, c x K
   % mv is K by 1 vector gives membership (1 to c) of each x
   
   % calculate g output
   dist=max(dist,1e-5); % to prevent divide by 0
   g=1./dist;  % weighting ~ 1/distance^2,  c x K
   tmp=1./sum(g); % normalize weighting to sum to unity  1 x K
   g=g*diag(tmp); % g is a c x K matrix
elseif c==1, % only one expert is used
   g=ones(k,1); 
   if nargin==2,
      xi=mean(x);
   end
end