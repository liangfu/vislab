% ghademo.m - generalized Hebbian learning demonstration
% call ghafun.m, randomize.m
% (C) 2001 by Yu Hen Hu
% created: 2/25/2001

clear all

% generate data samples
%K=15; M=3; N = 2;
K=input('dimension of feature space = ');
M=input('# of training vectors = ');
N=input(['# of principal component vectors, (< ' int2str(M) ') = ']);

x=randn(K,M);
disp('the randomly generated covariance matrix is:')
C = x'*x
[V,D]=eig(C);  % eigenvalue/eigenvector of covariance matrix
[Dsort,eidx]=sort(diag(-D)); % sort eigenvalue from largest to smallest
V=V(:,eidx); % sort eigenvector accordingly
yexact=x*V(:,1:N); % desireced output if exact principal components are there

% beginning of the algorithm
winit=randn(N,M)*0.05;   eta=0.005;
itermax=500;
w=ghafun(x,winit,itermax,eta);

% to compare with the principal components computed using eigenvalue
% decomposition, we first normalize each row of w:
disp(['first ' int2str(N) ' columns: true principal componenet vectors']);
disp(['last  ' int2str(N) ' columns: estimated principal component vectors'])
Trueest=[V(:,1:N) w']
